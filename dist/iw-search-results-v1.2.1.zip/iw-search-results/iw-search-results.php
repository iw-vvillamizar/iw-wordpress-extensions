<?php
/**
 * Plugin Name: IW Search Results
 * Plugin URI:  https://ingeweb.co/
 * Description: Resultados de búsqueda, buscador de productos y catálogo visual para WordPress y WooCommerce, compatibles con Divi 4.
 * Version:     1.2.1
 * Author:      IngeWeb.co
 * Author URI:  https://ingeweb.co/
 * Text Domain: iw-search-results
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 */

if (!defined('ABSPATH')) {
    exit;
}

final class IW_Search_Results {
    const VERSION = '1.2.1';
    const PRODUCT_SEARCH_PARAM = 'iw_product_search';
    const PRODUCT_FEATURES_PARAM = 'iw_include_features';

    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);

        // Búsqueda global estándar de WordPress / Divi.
        add_shortcode('iw_search_results', [$this, 'shortcode_results']);
        add_shortcode('iw_search_form', [$this, 'shortcode_form']);

        // Catálogo y búsqueda exclusiva de productos.
        add_shortcode('iw_product_catalog', [$this, 'shortcode_catalog']);
        add_shortcode('iw_product_search_form', [$this, 'shortcode_product_search_form']);
        add_shortcode('iw_product_search', [$this, 'shortcode_product_search']);
    }

    public function register_assets() {
        wp_register_style(
            'iw-search-results',
            plugin_dir_url(__FILE__) . 'assets/css/frontend.css',
            [],
            self::VERSION
        );
    }

    private function enqueue_assets() {
        wp_enqueue_style('iw-search-results');
    }

    private function sanitize_css_classes($classes) {
        $classes = preg_split('/\s+/', trim((string) $classes));
        $classes = array_filter(array_map('sanitize_html_class', $classes));
        return implode(' ', array_unique($classes));
    }

    private function get_search_term() {
        if (isset($_GET['s'])) {
            return sanitize_text_field(wp_unslash($_GET['s']));
        }

        $term = get_search_query(false);
        return is_string($term) ? sanitize_text_field($term) : '';
    }

    private function get_product_search_term() {
        if (!isset($_GET[self::PRODUCT_SEARCH_PARAM])) {
            return '';
        }

        return sanitize_text_field(wp_unslash($_GET[self::PRODUCT_SEARCH_PARAM]));
    }

    private function to_bool($value, $default = false) {
        if (null === $value || '' === $value) {
            return (bool) $default;
        }

        return in_array(strtolower((string) $value), ['1', 'yes', 'true', 'on', 'si', 'sí'], true);
    }

    private function get_product_features_flag($fallback = false) {
        if (isset($_GET[self::PRODUCT_FEATURES_PARAM])) {
            return $this->to_bool(sanitize_text_field(wp_unslash($_GET[self::PRODUCT_FEATURES_PARAM])), $fallback);
        }

        return (bool) $fallback;
    }

    public function shortcode_results($atts) {
        $atts = shortcode_atts([
            'products_per_page' => 12,
            'content_per_page'  => 6,
            'include_pages'     => 'yes',
            'show_counts'       => 'yes',
            'show_empty'        => 'no',
            'include_features'  => 'no',
            'class'             => '',
        ], $atts, 'iw_search_results');

        $term = $this->get_search_term();
        if ($term === '') {
            return '';
        }

        $this->enqueue_assets();

        $product_page = isset($_GET['iw_product_page']) ? max(1, absint($_GET['iw_product_page'])) : 1;
        $content_page = isset($_GET['iw_content_page']) ? max(1, absint($_GET['iw_content_page'])) : 1;

        $product_query = $this->get_search_product_query(
            $term,
            max(1, absint($atts['products_per_page'])),
            $product_page,
            $this->to_bool($atts['include_features'])
        );
        $content_query = $this->get_content_query(
            $term,
            max(1, absint($atts['content_per_page'])),
            $content_page,
            'yes' === strtolower((string) $atts['include_pages'])
        );

        $extra_class = $this->sanitize_css_classes($atts['class']);
        $show_counts = 'yes' === strtolower((string) $atts['show_counts']);
        $show_empty  = 'yes' === strtolower((string) $atts['show_empty']);

        ob_start();
        ?>
        <div class="iw-search-results<?php echo $extra_class ? ' ' . esc_attr($extra_class) : ''; ?>">
            <div class="iw-search-results__header">
                <p class="iw-search-results__eyebrow"><?php esc_html_e('Resultados de búsqueda', 'iw-search-results'); ?></p>
                <h1 class="iw-search-results__title">
                    <?php printf(esc_html__('Resultados para “%s”', 'iw-search-results'), esc_html($term)); ?>
                </h1>
            </div>

            <?php if ($product_query->have_posts() || $show_empty) : ?>
                <section class="iw-search-section iw-search-section--products" aria-labelledby="iw-search-products-title">
                    <?php $this->render_section_heading(__('Catálogo', 'iw-search-results'), __('Productos', 'iw-search-results'), $show_counts ? $product_query->found_posts : null, 'iw-search-products-title'); ?>
                    <?php if ($product_query->have_posts()) : ?>
                        <div class="iw-search-grid iw-search-grid--products">
                            <?php while ($product_query->have_posts()) : $product_query->the_post(); $this->render_product_card(get_the_ID()); endwhile; wp_reset_postdata(); ?>
                        </div>
                        <?php echo $this->render_pagination($product_query, 'iw_product_page', $product_page); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <?php else : ?>
                        <p class="iw-search-empty"><?php esc_html_e('No se encontraron productos.', 'iw-search-results'); ?></p>
                    <?php endif; ?>
                </section>
            <?php endif; ?>

            <?php if ($content_query->have_posts() || $show_empty) : ?>
                <section class="iw-search-section iw-search-section--content" aria-labelledby="iw-search-content-title">
                    <?php $this->render_section_heading(__('Contenido', 'iw-search-results'), __('Artículos y páginas', 'iw-search-results'), $show_counts ? $content_query->found_posts : null, 'iw-search-content-title'); ?>
                    <?php if ($content_query->have_posts()) : ?>
                        <div class="iw-search-grid iw-search-grid--content">
                            <?php while ($content_query->have_posts()) : $content_query->the_post(); $this->render_content_card(get_the_ID()); endwhile; wp_reset_postdata(); ?>
                        </div>
                        <?php echo $this->render_pagination($content_query, 'iw_content_page', $content_page); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <?php else : ?>
                        <p class="iw-search-empty"><?php esc_html_e('No se encontraron artículos o páginas.', 'iw-search-results'); ?></p>
                    <?php endif; ?>
                </section>
            <?php endif; ?>

            <?php if (!$product_query->have_posts() && !$content_query->have_posts()) : ?>
                <div class="iw-search-empty iw-search-empty--global">
                    <strong><?php esc_html_e('No encontramos resultados.', 'iw-search-results'); ?></strong>
                    <span><?php esc_html_e('Prueba con otro término de búsqueda.', 'iw-search-results'); ?></span>
                </div>
            <?php endif; ?>
        </div>
        <?php

        return trim(ob_get_clean());
    }

    /**
     * Catálogo de productos. Si existe ?iw_product_search=..., filtra exclusivamente productos.
     */
    public function shortcode_catalog($atts) {
        $atts = shortcode_atts([
            'per_page'        => 12,
            'columns'         => 4,
            'categories'      => 'yes',
            'category_parent' => '0',
            'show_counts'     => 'no',
            'orderby'         => 'menu_order title',
            'order'           => 'ASC',
            'class'           => '',
            'show_search_title' => 'yes',
            'include_features'  => 'auto',
        ], $atts, 'iw_product_catalog');

        $this->enqueue_assets();

        $per_page = max(1, absint($atts['per_page']));
        $columns  = min(6, max(1, absint($atts['columns'])));
        $page     = isset($_GET['iw_catalog_page']) ? max(1, absint($_GET['iw_catalog_page'])) : 1;
        $selected = $this->get_catalog_category();
        $product_search = $this->get_product_search_term();
        $include_features = ('auto' === strtolower((string) $atts['include_features']))
            ? $this->get_product_features_flag(false)
            : $this->to_bool($atts['include_features']);

        $query = $this->get_catalog_query(
            $per_page,
            $page,
            $selected,
            $atts['orderby'],
            $atts['order'],
            $product_search,
            $include_features
        );

        $extra_class = $this->sanitize_css_classes($atts['class']);
        $wrapper_classes = trim('iw-product-catalog ' . $extra_class);

        ob_start();
        ?>
        <div class="<?php echo esc_attr($wrapper_classes); ?>" style="--iw-catalog-columns: <?php echo esc_attr((string) $columns); ?>;">
            <?php if ($product_search !== '' && 'yes' === strtolower((string) $atts['show_search_title'])) : ?>
                <div class="iw-product-search-summary">
                    <span><?php esc_html_e('Resultados de productos para', 'iw-search-results'); ?></span>
                    <strong>“<?php echo esc_html($product_search); ?>”</strong>
                    <span class="iw-product-search-summary__count"><?php echo esc_html((string) $query->found_posts); ?></span>
                </div>
            <?php endif; ?>

            <?php if ('yes' === strtolower((string) $atts['categories'])) : ?>
                <?php $this->render_category_filters($selected, absint($atts['category_parent']), 'yes' === strtolower((string) $atts['show_counts'])); ?>
            <?php endif; ?>

            <?php if ($query->have_posts()) : ?>
                <div class="iw-search-grid iw-search-grid--products iw-product-catalog__grid">
                    <?php while ($query->have_posts()) : $query->the_post(); $this->render_product_card(get_the_ID()); endwhile; wp_reset_postdata(); ?>
                </div>
                <?php echo $this->render_pagination($query, 'iw_catalog_page', $page); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <?php else : ?>
                <p class="iw-search-empty">
                    <?php
                    if ($product_search !== '') {
                        printf(esc_html__('No se encontraron productos para “%s”.', 'iw-search-results'), esc_html($product_search));
                    } else {
                        esc_html_e('No se encontraron productos en esta categoría.', 'iw-search-results');
                    }
                    ?>
                </p>
            <?php endif; ?>
        </div>
        <?php

        return trim(ob_get_clean());
    }

    /**
     * Formulario de búsqueda exclusiva de productos.
     * La acción del formulario es la misma URL donde se inserta el shortcode.
     * No usa ?s= y por tanto no activa la búsqueda global de WordPress.
     */
    public function shortcode_product_search_form($atts) {
        $atts = shortcode_atts([
            'placeholder'       => __('Buscar productos…', 'iw-search-results'),
            'button'            => __('Buscar', 'iw-search-results'),
            'class'             => '',
            'module_id'         => 'mod-product-search',
            'module_class'      => 'mod-product-search',
            'include_features'  => 'no',
            'preserve_category' => 'yes',
        ], $atts, 'iw_product_search_form');

        $this->enqueue_assets();

        $extra_class = $this->sanitize_css_classes($atts['class']);
        $module_class = $this->sanitize_css_classes($atts['module_class']);
        $term = $this->get_product_search_term();
        $action = $this->current_base_url();
        $selected = $this->get_catalog_category();
        $include_features = $this->to_bool($atts['include_features']);
        $input_id = 'iw-product-search-' . wp_unique_id();
        $wrapper_classes = trim('et_pb_module et_pb_search et_pb_search_0_tb_body ' . $module_class . ' et_pb_text_align_left et_pb_bg_layout_light ' . $extra_class);

        ob_start();
        ?>
        <div id="<?php echo esc_attr($atts['module_id']); ?>" class="<?php echo esc_attr($wrapper_classes); ?>">
            <form role="search" method="get" class="et_pb_searchform iw-search-form iw-product-search-form" action="<?php echo esc_url($action); ?>">
                <div>
                    <label class="screen-reader-text" for="<?php echo esc_attr($input_id); ?>"><?php esc_html_e('Buscar productos:', 'iw-search-results'); ?></label>
                    <input id="<?php echo esc_attr($input_id); ?>" type="text" name="<?php echo esc_attr(self::PRODUCT_SEARCH_PARAM); ?>" value="<?php echo esc_attr($term); ?>" placeholder="<?php echo esc_attr($atts['placeholder']); ?>" class="et_pb_s">
                    <?php if ($include_features) : ?>
                        <input type="hidden" name="<?php echo esc_attr(self::PRODUCT_FEATURES_PARAM); ?>" value="yes">
                    <?php endif; ?>
                    <?php if ('yes' === strtolower((string) $atts['preserve_category']) && $selected !== '') : ?>
                        <input type="hidden" name="iw_product_cat" value="<?php echo esc_attr($selected); ?>">
                    <?php endif; ?>
                    <input type="submit" value="<?php echo esc_attr($atts['button']); ?>" class="et_pb_searchsubmit">
                </div>
            </form>
        </div>
        <?php
        return trim(ob_get_clean());
    }

    /**
     * Shortcode de conveniencia: formulario + catálogo filtrable en la misma página.
     */
    public function shortcode_product_search($atts) {
        $atts = shortcode_atts([
            'placeholder'      => __('Buscar productos…', 'iw-search-results'),
            'button'           => __('Buscar', 'iw-search-results'),
            'per_page'         => 12,
            'columns'          => 4,
            'categories'       => 'yes',
            'category_parent'  => '0',
            'show_counts'      => 'no',
            'orderby'          => 'menu_order title',
            'order'            => 'ASC',
            'class'            => '',
            'include_features' => 'no',
        ], $atts, 'iw_product_search');

        $form = $this->shortcode_product_search_form([
            'placeholder' => $atts['placeholder'],
            'button'      => $atts['button'],
            'class'            => $atts['class'],
            'include_features' => $atts['include_features'],
        ]);

        $catalog = $this->shortcode_catalog([
            'per_page'        => $atts['per_page'],
            'columns'         => $atts['columns'],
            'categories'      => $atts['categories'],
            'category_parent' => $atts['category_parent'],
            'show_counts'     => $atts['show_counts'],
            'orderby'         => $atts['orderby'],
            'order'           => $atts['order'],
            'class'            => $atts['class'],
            'include_features' => $atts['include_features'],
        ]);

        return '<div class="iw-product-search">' . $form . $catalog . '</div>';
    }

    private function get_catalog_category() {
        if (isset($_GET['iw_product_cat'])) {
            return sanitize_title(wp_unslash($_GET['iw_product_cat']));
        }

        if (is_tax('product_cat')) {
            $obj = get_queried_object();
            if ($obj && !is_wp_error($obj) && !empty($obj->slug)) {
                return sanitize_title($obj->slug);
            }
        }

        return '';
    }

    private function get_catalog_query($per_page, $page, $selected, $orderby, $order, $product_search = '', $include_features = false) {
        $allowed_orderby = ['menu_order title', 'title', 'date', 'modified', 'rand', 'relevance date'];
        if (!in_array($orderby, $allowed_orderby, true)) {
            $orderby = 'menu_order title';
        }

        $order = strtoupper((string) $order);
        if (!in_array($order, ['ASC', 'DESC'], true)) {
            $order = 'ASC';
        }

        $args = [
            'post_type'           => 'product',
            'post_status'         => 'publish',
            'posts_per_page'      => $per_page,
            'paged'               => $page,
            'ignore_sticky_posts' => true,
            'orderby'             => $orderby,
            'order'               => $order,
        ];

        if ($product_search !== '') {
            $ids = $this->find_product_ids($product_search, $include_features);
            $args['post__in'] = $ids ?: [0];
            $args['orderby'] = 'post__in';
        }

        $tax_query = $this->get_visibility_tax_query();

        if ($selected) {
            $tax_query[] = [
                'taxonomy'         => 'product_cat',
                'field'            => 'slug',
                'terms'            => [$selected],
                'include_children' => true,
            ];
        }

        if ($tax_query) {
            $args['tax_query'] = $tax_query;
        }

        return new WP_Query($args);
    }

    private function render_category_filters($selected, $parent, $show_counts) {
        $terms = get_terms([
            'taxonomy'   => 'product_cat',
            'hide_empty' => true,
            'parent'     => $parent,
            'orderby'    => 'menu_order',
            'order'      => 'ASC',
        ]);

        if (is_wp_error($terms) || !$terms) {
            return;
        }

        $all_url = $this->catalog_filter_url('');
        ?>
        <nav class="iw-catalog-filters" aria-label="<?php esc_attr_e('Filtrar productos por categoría', 'iw-search-results'); ?>">
            <a class="iw-catalog-filter<?php echo '' === $selected ? ' is-active' : ''; ?>" href="<?php echo esc_url($all_url); ?>">
                <?php esc_html_e('Todos', 'iw-search-results'); ?>
            </a>
            <?php foreach ($terms as $term) : ?>
                <a class="iw-catalog-filter<?php echo $selected === $term->slug ? ' is-active' : ''; ?>" href="<?php echo esc_url($this->catalog_filter_url($term->slug)); ?>">
                    <span><?php echo esc_html($term->name); ?></span>
                    <?php if ($show_counts) : ?><small><?php echo esc_html((string) $term->count); ?></small><?php endif; ?>
                </a>
            <?php endforeach; ?>
        </nav>
        <?php
    }

    private function catalog_filter_url($slug) {
        $args = $_GET;
        unset($args['iw_catalog_page'], $args['iw_product_cat']);

        if ($slug) {
            $args['iw_product_cat'] = $slug;
        }

        $args = array_map('sanitize_text_field', wp_unslash($args));
        $base = is_tax('product_cat') && function_exists('wc_get_page_permalink')
            ? wc_get_page_permalink('shop')
            : $this->current_base_url();

        return $args ? add_query_arg($args, $base) : $base;
    }

    private function current_base_url() {
        $scheme = is_ssl() ? 'https' : 'http';
        $host = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'])) : wp_parse_url(home_url('/'), PHP_URL_HOST);
        $uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
        $path = strtok($uri, '?');
        return esc_url_raw($scheme . '://' . $host . $path);
    }

    private function get_search_product_query($term, $per_page, $page, $include_features = false) {
        $ids = $this->find_product_ids($term, $include_features);

        $args = [
            'post_type'           => 'product',
            'post_status'         => 'publish',
            'posts_per_page'      => $per_page,
            'paged'               => $page,
            'ignore_sticky_posts' => true,
            'orderby'             => 'post__in',
            'post__in'            => $ids ?: [0],
        ];

        $tax_query = $this->get_visibility_tax_query();
        if ($tax_query) {
            $args['tax_query'] = $tax_query;
        }

        return new WP_Query($args);
    }

    private function get_visibility_tax_query() {
        $tax_query = [];

        if (function_exists('wc_get_product_visibility_term_ids')) {
            $visibility = wc_get_product_visibility_term_ids();
            if (!empty($visibility['exclude-from-catalog'])) {
                $tax_query[] = [
                    'taxonomy' => 'product_visibility',
                    'field'    => 'term_taxonomy_id',
                    'terms'    => [(int) $visibility['exclude-from-catalog']],
                    'operator' => 'NOT IN',
                ];
            }
        }

        return $tax_query;
    }

    private function find_product_ids($term, $include_features = false) {
        global $wpdb;

        $like = '%' . $wpdb->esc_like($term) . '%';
        $ids = [];

        // 1) Título del producto.
        $title_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID
             FROM {$wpdb->posts}
             WHERE post_type = 'product'
               AND post_status = 'publish'
               AND post_title LIKE %s
             ORDER BY post_title ASC",
            $like
        ));

        foreach ($title_ids as $id) {
            $ids[] = absint($id);
        }

        // 2) SKU.
        $sku_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT p.ID
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
             WHERE p.post_type = 'product'
               AND p.post_status = 'publish'
               AND pm.meta_key = '_sku'
               AND pm.meta_value LIKE %s
             ORDER BY p.post_title ASC",
            $like
        ));

        foreach ($sku_ids as $id) {
            $ids[] = absint($id);
        }

        // 3) Características de IW Product Features, solo cuando se solicita explícitamente.
        if ($include_features) {
            $feature_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT p.ID
                 FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
                 WHERE p.post_type = 'product'
                   AND p.post_status = 'publish'
                   AND pm.meta_key = '_iw_product_features'
                   AND pm.meta_value LIKE %s
                 ORDER BY p.post_title ASC",
                $like
            ));

            foreach ($feature_ids as $id) {
                $ids[] = absint($id);
            }
        }

        return array_values(array_unique(array_filter($ids)));
    }

    private function get_content_query($term, $per_page, $page, $include_pages) {
        return new WP_Query([
            'post_type'           => $include_pages ? ['post', 'page'] : ['post'],
            'post_status'         => 'publish',
            's'                   => $term,
            'posts_per_page'      => $per_page,
            'paged'               => $page,
            'ignore_sticky_posts' => true,
        ]);
    }

    private function render_section_heading($kicker, $title, $count = null, $id = '') {
        ?>
        <div class="iw-search-section__heading">
            <div>
                <span class="iw-search-section__kicker"><?php echo esc_html($kicker); ?></span>
                <h2<?php echo $id ? ' id="' . esc_attr($id) . '"' : ''; ?>><?php echo esc_html($title); ?></h2>
            </div>
            <?php if (null !== $count) : ?><span class="iw-search-section__count"><?php echo esc_html((string) $count); ?></span><?php endif; ?>
        </div>
        <?php
    }

    private function render_product_card($post_id) {
        $product = function_exists('wc_get_product') ? wc_get_product($post_id) : null;
        if (!$product) {
            return;
        }

        $image = get_the_post_thumbnail_url($post_id, 'woocommerce_thumbnail');
        if (!$image && function_exists('wc_placeholder_img_src')) {
            $image = wc_placeholder_img_src('woocommerce_thumbnail');
        }

        $terms = get_the_terms($post_id, 'product_cat');
        $category = (!is_wp_error($terms) && !empty($terms)) ? $terms[0]->name : __('Producto', 'iw-search-results');
        ?>
        <article class="iw-search-card iw-search-card--product">
            <a class="iw-search-card__media" href="<?php echo esc_url(get_permalink($post_id)); ?>" aria-label="<?php echo esc_attr(get_the_title($post_id)); ?>">
                <?php if ($image) : ?><img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr(get_the_title($post_id)); ?>" loading="lazy"><?php endif; ?>
            </a>
            <div class="iw-search-card__body">
                <span class="iw-search-card__meta"><?php echo esc_html($category); ?></span>
                <h3 class="iw-search-card__title"><a href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php echo esc_html(get_the_title($post_id)); ?></a></h3>
                <?php if ($product->get_sku()) : ?><div class="iw-search-card__sku"><?php echo esc_html(sprintf(__('SKU: %s', 'iw-search-results'), $product->get_sku())); ?></div><?php endif; ?>
                <a class="iw-search-card__link" href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php esc_html_e('Ver producto', 'iw-search-results'); ?><span aria-hidden="true">→</span></a>
            </div>
        </article>
        <?php
    }

    private function render_content_card($post_id) {
        $image = get_the_post_thumbnail_url($post_id, 'medium_large');
        $type  = get_post_type($post_id);
        $label = 'page' === $type ? __('Página', 'iw-search-results') : __('Artículo', 'iw-search-results');
        $excerpt = get_the_excerpt($post_id);
        ?>
        <article class="iw-search-card iw-search-card--content">
            <?php if ($image) : ?><a class="iw-search-card__media" href="<?php echo esc_url(get_permalink($post_id)); ?>" aria-label="<?php echo esc_attr(get_the_title($post_id)); ?>"><img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr(get_the_title($post_id)); ?>" loading="lazy"></a><?php endif; ?>
            <div class="iw-search-card__body">
                <span class="iw-search-card__meta"><?php echo esc_html($label); ?></span>
                <h3 class="iw-search-card__title"><a href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php echo esc_html(get_the_title($post_id)); ?></a></h3>
                <?php if ($excerpt) : ?><p class="iw-search-card__excerpt"><?php echo esc_html(wp_trim_words($excerpt, 22)); ?></p><?php endif; ?>
                <a class="iw-search-card__link" href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php esc_html_e('Leer más', 'iw-search-results'); ?><span aria-hidden="true">→</span></a>
            </div>
        </article>
        <?php
    }

    private function render_pagination($query, $param, $current) {
        if ($query->max_num_pages <= 1) {
            return '';
        }

        $base_args = $_GET;
        unset($base_args[$param]);
        $base_args = array_map('sanitize_text_field', wp_unslash($base_args));
        $base_url = $base_args ? add_query_arg($base_args, $this->current_base_url()) : $this->current_base_url();

        $links = paginate_links([
            'base'      => esc_url_raw(add_query_arg($param, '%#%', $base_url)),
            'format'    => '',
            'current'   => $current,
            'total'     => (int) $query->max_num_pages,
            'type'      => 'array',
            'prev_text' => '←',
            'next_text' => '→',
        ]);

        if (!$links) {
            return '';
        }

        return '<nav class="iw-search-pagination" aria-label="Paginación">' . implode('', $links) . '</nav>';
    }

    /**
     * Buscador global. Se conserva exactamente con ?s= y action a home_url('/').
     */
    public function shortcode_form($atts) {
        $atts = shortcode_atts([
            'placeholder'  => '',
            'button'       => __('Search', 'iw-search-results'),
            'class'        => '',
            'module_id'    => 'mod-blog-hero-search',
            'module_class' => 'mod-blog-hero-search',
        ], $atts, 'iw_search_form');

        $this->enqueue_assets();

        $extra_class = $this->sanitize_css_classes($atts['class']);
        $module_class = $this->sanitize_css_classes($atts['module_class']);
        $term = $this->get_search_term();
        $input_id = 'iw-global-search-' . wp_unique_id();
        $wrapper_classes = trim('et_pb_module et_pb_search et_pb_search_0_tb_body ' . $module_class . ' et_pb_text_align_left et_pb_bg_layout_light ' . $extra_class);

        ob_start();
        ?>
        <div id="<?php echo esc_attr($atts['module_id']); ?>" class="<?php echo esc_attr($wrapper_classes); ?>">
            <form role="search" method="get" class="et_pb_searchform iw-search-form" action="<?php echo esc_url(home_url('/')); ?>">
                <div>
                    <label class="screen-reader-text" for="<?php echo esc_attr($input_id); ?>"><?php esc_html_e('Search for:', 'iw-search-results'); ?></label>
                    <input id="<?php echo esc_attr($input_id); ?>" type="text" name="s" value="<?php echo esc_attr($term); ?>" placeholder="<?php echo esc_attr($atts['placeholder']); ?>" class="et_pb_s">
                    <input type="hidden" name="et_pb_searchform_submit" value="et_search_proccess">
                    <input type="hidden" name="et_pb_include_posts" value="yes">
                    <input type="hidden" name="et_pb_include_pages" value="yes">
                    <input type="submit" value="<?php echo esc_attr($atts['button']); ?>" class="et_pb_searchsubmit">
                </div>
            </form>
        </div>
        <?php
        return trim(ob_get_clean());
    }
}

new IW_Search_Results();
