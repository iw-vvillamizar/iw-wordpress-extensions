=== IW Search Results ===
Contributors: ingeweb
Tags: search, catalog, divi, woocommerce, wordpress
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.2.1
License: GPLv2 or later

Resultados de búsqueda global, catálogo visual y búsqueda exclusiva de productos para WooCommerce.

== Shortcodes ==

[iw_search_results]
Resultados de búsqueda global separados entre productos y contenido. Lee ?s=.
Por defecto los productos se buscan por título y SKU.
Para incluir también las características de IW Product Features:
[iw_search_results include_features="yes"]

[iw_search_form]
Formulario de búsqueda global. Conserva el comportamiento estándar de Divi/WordPress y su marcado/clases principales.

[iw_product_catalog]
Catálogo completo de productos con filtros por categoría y paginación.
Si existe ?iw_product_search=termino, filtra únicamente productos dentro de la misma página.
El parámetro include_features="auto" (predeterminado) respeta lo enviado por [iw_product_search_form].
También se puede forzar:
[iw_product_catalog include_features="yes"]
[iw_product_catalog include_features="no"]

[iw_product_search_form]
Formulario exclusivo para productos. Mantiene la búsqueda en la misma URL/página y utiliza marcado compatible con el Search Module de Divi.

Búsqueda normal por título y SKU:
[iw_product_search_form]

Búsqueda por título, SKU y características:
[iw_product_search_form include_features="yes"]

Al usar include_features="yes" el formulario envía:
?iw_product_search=termino&iw_include_features=yes

Para mostrar los resultados en la misma página coloca también:
[iw_product_catalog]

[iw_product_search]
Shortcode de conveniencia que incluye formulario + catálogo.

Solo título y SKU:
[iw_product_search per_page="12" columns="4" categories="yes"]

Título, SKU y características:
[iw_product_search include_features="yes" per_page="12" columns="4" categories="yes"]

== Características ==

La búsqueda opcional de características consulta el meta:
_iw_product_features

Ese meta es utilizado por IW Product Features.
Si include_features no se activa, no se consulta ese campo.

== Marcado de formularios ==

Los formularios incluyen las clases principales del Search Module de Divi:
et_pb_module et_pb_search et_pb_search_0_tb_body
et_pb_searchform
et_pb_s
et_pb_searchsubmit

El buscador global conserva además los hidden inputs de Divi para posts y páginas.

== Diseño ==

Las tarjetas de producto se comparten entre búsqueda global, catálogo y búsqueda exclusiva de productos.
El CSS consume las variables globales definidas en custom.css.
