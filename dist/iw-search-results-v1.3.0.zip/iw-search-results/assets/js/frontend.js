(function () {
    'use strict';

    function initCategorySelector(selector) {
        var all = selector.querySelector('[data-iw-category-all]');
        var items = Array.prototype.slice.call(selector.querySelectorAll('[data-iw-category-item]'));
        var label = selector.querySelector('[data-iw-category-label]');

        if (!all || !items.length || !label) {
            return;
        }

        var defaultLabel = all.closest('label').querySelector('span').textContent.trim();

        function updateLabel() {
            var checked = items.filter(function (item) { return item.checked; });

            if (!checked.length) {
                all.checked = true;
                label.textContent = defaultLabel;
                return;
            }

            all.checked = false;
            label.textContent = checked.length === 1
                ? '1 categoría'
                : checked.length + ' categorías';
        }

        all.addEventListener('change', function () {
            if (all.checked) {
                items.forEach(function (item) { item.checked = false; });
            } else if (!items.some(function (item) { return item.checked; })) {
                all.checked = true;
            }
            updateLabel();
        });

        items.forEach(function (item) {
            item.addEventListener('change', function () {
                if (item.checked) {
                    all.checked = false;
                }
                updateLabel();
            });
        });

        updateLabel();
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-iw-category-selector]').forEach(initCategorySelector);
    });
}());
